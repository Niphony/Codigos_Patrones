package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaabstracta.Ryzen;

public class R7 implements Ryzen {
    
    @Override
    public String procesador(){
        return "Gama media-alta, excelente para multitarea, edición de video y juegos exigentes; ofrece un buen equilibrio entre rendimiento y precio.";
    }


}
