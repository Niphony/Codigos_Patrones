package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaabstracta.Ryzen;

public class R9 implements Ryzen {
     
    @Override
    public String procesador(){
        return "Procesador de gama alta, diseñado para cargas de trabajo intensivas como diseño 3D, desarrollo profesional y gaming extremo con alto rendimiento.";
    }

}
