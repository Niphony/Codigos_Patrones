package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaabstracta.Intel;

public class I9 implements Intel {
     
    @Override
    public String procesador(){
        return "Procesador Intel Core i9 - Gama alta, ideal para alto rendimiento y gaming.";
    }

}
