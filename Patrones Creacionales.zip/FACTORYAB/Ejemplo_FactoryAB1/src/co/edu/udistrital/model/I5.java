package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaabstracta.Intel;

public class I5 implements Intel {
    
    @Override
    public String procesador(){
        return "Procesador Intel Core i5 - Gama media, equilibrado para trabajo y juego.";
    }


}
