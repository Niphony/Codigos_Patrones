package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaabstracta.Intel;

public class I3 implements Intel {

    @Override
    public String procesador(){
        return "Procesador Intel Core i3 - Gama baja, eficiente para tareas básicas.";
    }

}
