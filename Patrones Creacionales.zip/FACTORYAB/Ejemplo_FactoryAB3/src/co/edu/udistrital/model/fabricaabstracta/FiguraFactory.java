package co.edu.udistrital.model.fabricaabstracta;

public interface FiguraFactory {
	
	Figura Crearcirculo();
	
}
