package co.edu.udistrital.model.fabricaabstracta;

public interface Figura {
	
		double Calcular(double entrada);

}
