package controller;

public class Main {
    public static void main(String[] args) {
        Controller control = new Controller();
        control.run();
    }

}
