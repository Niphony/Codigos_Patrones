package co.edu.udistrital.model.interfaz;

public interface Bebida {
	
	void preparar();
	
	void servir();
	
	String tipo();
	
	

}
