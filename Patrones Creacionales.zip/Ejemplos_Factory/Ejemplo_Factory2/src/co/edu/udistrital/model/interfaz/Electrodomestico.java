package co.edu.udistrital.model.interfaz;

public interface Electrodomestico {
	
	void encender();
	
	void apagar();
	
	String tipo();
	
	

}
