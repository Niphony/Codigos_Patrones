package co.edu.udistrital.model.interfaz;

public interface Transporte {
	
	public void arrancar();
	
	public void detener();
	
	public String tipo();
	
	

}
