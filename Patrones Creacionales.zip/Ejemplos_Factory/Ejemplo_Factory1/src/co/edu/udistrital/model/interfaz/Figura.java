package co.edu.udistrital.model.interfaz;

public interface Figura {
		
	public String tipo();
	
	

}
