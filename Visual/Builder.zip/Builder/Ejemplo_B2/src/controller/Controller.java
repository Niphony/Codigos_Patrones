package controller;

import model.Recibo;
import model.ReciboBuilder;
import view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run(){
        vista.mostrarInformacion("Bienvenido al sistema de recibos");
        String tipo = vista.leerTexto("Ingrese el tipo de recibo: ");
        double valor = Double.parseDouble(vista.leerTexto("Ingrese el valor del recibo: "));

        datosrecibo(tipo, valor);
    }

    public void datosrecibo(String tipo, double valor) {
        ReciboBuilder builder = new ReciboBuilder();
        Recibo recibo = builder.setTipo(tipo)
                                .setValor(valor)
                                .build();

        vista.mostrarInformacion("El recibo que tiene que pagar es de: " + recibo.getTipo() + " y con valor de: " + recibo.getValor());
    }

}
