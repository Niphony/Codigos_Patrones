package model;

public interface Lapiz {

    void escribir();

}
