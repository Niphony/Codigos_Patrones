package controller;

import model.Menu;
import model.componentes.MenuComponent;
import model.hoja.MenuItem;
import view.VistaConsola;

public class Controller {
    private MenuComponent rootMenu;
    private VistaConsola vista;

    public void MenuController(MenuComponent rootMenu, VistaConsola vista) {
        this.rootMenu = rootMenu;
        this.vista = vista;
    }

    public void mostrarMenu() {
        vista.displayMenu(rootMenu);
    }

    public void run(){
        // Crear menú principal y submenús
        MenuComponent desayuno = new Menu("Menú Desayuno");
        MenuComponent almuerzo = new Menu("Menú Almuerzo");

        desayuno.add(new MenuItem("Huevos"));
        desayuno.add(new MenuItem("Café"));

        almuerzo.add(new MenuItem("Arroz con pollo"));
        almuerzo.add(new MenuItem("Sopa de verduras"));

        MenuComponent menuPrincipal = new Menu("Menú Principal");
        menuPrincipal.add(desayuno);
        menuPrincipal.add(almuerzo);

    }
}
